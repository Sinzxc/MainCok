const line = document.querySelector('.card-navigation-line');
const shadow =  document.querySelector('.shadow');